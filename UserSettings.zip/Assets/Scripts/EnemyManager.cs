using System.Collections;
using System.Collections.Generic;
using TMPro.EditorUtilities;
using UnityEngine;
using UnityEngine.UI;

public class EnemyManager : MonoBehaviour
{
    public Vector2 initPosition;
    public int life;
    public int speedMove;
    public float rateAttack;
    public Vector2Int atackDamage;
    public Image lifeBar;
    public GameObject destroyDead;

    protected Vector2 currentTile, stepTile, nextTile;
    protected bool move;
    protected float rateTime;
    protected int maxLife;


    public virtual void GetDamage(int damage)
    {
        life -= damage;
        if (life < 0)
        {
            //Aqui muere el enemigo. TODO: Crear particulas y sonido de muerte
            Destroy((destroyDead != null) ? destroyDead : gameObject);
        }
        else
        {
            //Aqui recibe da�o. TODO: Crear particulas y sonido de muerte
        }
        lifeBar.fillAmount = (float)life / (float)maxLife;
    }
}
