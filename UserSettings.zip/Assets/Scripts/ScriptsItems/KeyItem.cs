using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "KeyItem", menuName = "Item/KeyItem")]
public class KeyItem : ItemManager
{
    public string[] idChest;
}
