using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "HealPotion", menuName = "Item/HealPotion")]
public class HealPotion : ItemManager
{
    public int lifeRegeneration;
}
